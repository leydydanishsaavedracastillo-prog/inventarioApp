import 'package:flutter/material.dart';
import 'models/producto.dart';
import 'productos_page.dart';

void main() {
  runApp(const InventarioApp());
}

class InventarioApp extends StatelessWidget {
  const InventarioApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'InventarioApp',
      theme: ThemeData(
        useMaterial3: true,
        colorSchemeSeed: Colors.blue,
        inputDecorationTheme: const InputDecorationTheme(
          border: OutlineInputBorder(),
        ),
      ),
      home: const RegistroProductoPage(),
    );
  }
}

class RegistroProductoPage extends StatefulWidget {
  const RegistroProductoPage({super.key});

  @override
  State<RegistroProductoPage> createState() => _RegistroProductoPageState();
}

class _RegistroProductoPageState extends State<RegistroProductoPage> {
  // Formulario
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();

  // Controladores
  final TextEditingController _codigoController = TextEditingController();
  final TextEditingController _nombreController = TextEditingController();
  final TextEditingController _precioController = TextEditingController();

  // Lista temporal en memoria
  final List<Producto> _productos = <Producto>[];

  // Valores de los controles
  String? _categoria;
  String _estado = 'Disponible';
  double _stock = 0;
  DateTime? _fechaIngreso;
  bool _perecible = false;

  // Categorías solicitadas por el profesor
  final List<String> _categorias = <String>[
    'Abarrotes',
    'Bebidas',
    'Limpieza',
    'Golosinas',
    'Lácteos',
    'Otro',
  ];

  // Selector de fecha
  Future<void> _seleccionarFecha() async {
    final DateTime hoy = DateTime.now();

    final DateTime? fecha = await showDatePicker(
      context: context,
      initialDate: _fechaIngreso ?? hoy,
      firstDate: DateTime(2000),
      lastDate: hoy,
      helpText: 'Seleccione la fecha de ingreso',
    );

    if (fecha != null) {
      setState(() {
        _fechaIngreso = fecha;
      });
    }
  }

  // Capitaliza cada palabra del nombre
  String _capitalizarPalabras(String texto) {
    return texto
        .trim()
        .split(RegExp(r'\s+'))
        .map(
          (palabra) => palabra.isEmpty
              ? ''
              : '${palabra[0].toUpperCase()}${palabra.substring(1).toLowerCase()}',
        )
        .join(' ');
  }

  // Registrar producto
  void _registrarProducto() {
    if (!_formKey.currentState!.validate()) {
      return;
    }

    // Validación de controles que no son TextFormField
    if (_categoria == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Seleccione una categoría.'),
        ),
      );
      return;
    }

    if (_fechaIngreso == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Seleccione la fecha de ingreso.'),
        ),
      );
      return;
    }

    final Producto producto = Producto(
      codigo: _codigoController.text.trim(),
      nombre: _capitalizarPalabras(_nombreController.text),
      categoria: _categoria!,
      precio: double.parse(_precioController.text.trim()),
      stock: _stock.round(),
      estado: _estado,
      fechaIngreso: _fechaIngreso!,
      perecible: _perecible,
    );

    // Guardar en memoria
    setState(() {
      _productos.add(producto);
    });

    // Limpiar formulario
    _codigoController.clear();
    _nombreController.clear();
    _precioController.clear();

    setState(() {
      _categoria = null;
      _estado = 'Disponible';
      _stock = 0;
      _fechaIngreso = null;
      _perecible = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(
        content: Text('Producto registrado correctamente.'),
      ),
    );
  }

  // Ir a la tabla de productos
  void _mostrarProductos() {
    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (context) => ProductosPage(
          productos: _productos,
        ),
      ),
    ).then((_) {
      setState(() {});
    });
  }

  @override
  void dispose() {
    _codigoController.dispose();
    _nombreController.dispose();
    _precioController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Row(
          children: [
            const Text('InventarioApp'),
            const SizedBox(width: 10),
            Badge(
              label: Text('${_productos.length}'),
              child: const Icon(Icons.inventory_2_outlined),
            ),
          ],
        ),
        actions: [
          IconButton(
            tooltip: 'Ver productos',
            icon: const Icon(Icons.table_view),
            onPressed: _mostrarProductos,
          ),
        ],
      ),

      body: Form(
        key: _formKey,
        child: SingleChildScrollView(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const Text(
                'Registro de Productos',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.bold,
                ),
              ),

              const SizedBox(height: 8),

              const Text(
                'Ingrese los datos del producto que entra al almacén.',
              ),

              const SizedBox(height: 20),

              // CÓDIGO
              TextFormField(
                controller: _codigoController,
                keyboardType: TextInputType.number,
                maxLength: 6,
                decoration: const InputDecoration(
                  labelText: 'Código del producto',
                  hintText: '6 dígitos',
                  prefixIcon: Icon(Icons.qr_code),
                ),
                validator: (value) {
                  final String texto = value?.trim() ?? '';

                  if (texto.isEmpty) {
                    return 'El código es obligatorio.';
                  }

                  if (!RegExp(r'^\d{6}$').hasMatch(texto)) {
                    return 'Debe contener exactamente 6 dígitos.';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 12),

              // NOMBRE
              TextFormField(
                controller: _nombreController,
                textCapitalization: TextCapitalization.words,
                decoration: const InputDecoration(
                  labelText: 'Nombre del producto',
                  prefixIcon: Icon(Icons.shopping_bag_outlined),
                ),
                validator: (value) {
                  final String texto = value?.trim() ?? '';

                  if (texto.isEmpty) {
                    return 'El nombre es obligatorio.';
                  }

                  if (texto.length < 2) {
                    return 'Ingrese un nombre válido.';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 20),

              // CATEGORÍA
              DropdownButtonFormField<String>(
                initialValue: _categoria,
                decoration: const InputDecoration(
                  labelText: 'Categoría',
                  prefixIcon: Icon(Icons.category_outlined),
                ),
                items: _categorias.map((String categoria) {
                  return DropdownMenuItem<String>(
                    value: categoria,
                    child: Text(categoria),
                  );
                }).toList(),
                onChanged: (String? valor) {
                  setState(() {
                    _categoria = valor;
                  });
                },
              ),

              const SizedBox(height: 20),

              // PRECIO
              TextFormField(
                controller: _precioController,
                keyboardType: const TextInputType.numberWithOptions(
                  decimal: true,
                ),
                decoration: const InputDecoration(
                  labelText: 'Precio unitario (S/)',
                  hintText: 'Ejemplo: 12.50',
                  prefixIcon: Icon(Icons.attach_money),
                ),
                validator: (value) {
                  final String texto = value?.trim() ?? '';

                  if (texto.isEmpty) {
                    return 'El precio es obligatorio.';
                  }

                  final double? precio = double.tryParse(texto);

                  if (precio == null) {
                    return 'Ingrese un precio válido.';
                  }

                  if (precio <= 0) {
                    return 'El precio debe ser mayor que 0.';
                  }

                  return null;
                },
              ),

              const SizedBox(height: 20),

              // STOCK
              Text(
                'Cantidad en stock: ${_stock.round()}',
                style: const TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),

              Slider(
                value: _stock,
                min: 0,
                max: 100,
                divisions: 100,
                label: '${_stock.round()}',
                onChanged: (double valor) {
                  setState(() {
                    _stock = valor;
                  });
                },
              ),

              const SizedBox(height: 12),

              // ESTADO
              const Text(
                'Estado del producto',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),

              const SizedBox(height: 8),

              Center(
                child: SegmentedButton<String>(
                  segments: const [
                    ButtonSegment<String>(
                      value: 'Disponible',
                      label: Text('Disponible'),
                      icon: Icon(Icons.check_circle_outline),
                    ),
                    ButtonSegment<String>(
                      value: 'Agotado',
                      label: Text('Agotado'),
                      icon: Icon(Icons.cancel_outlined),
                    ),
                  ],
                  selected: <String>{_estado},
                  onSelectionChanged: (Set<String> seleccion) {
                    setState(() {
                      _estado = seleccion.first;
                    });
                  },
                ),
              ),

              const SizedBox(height: 20),

              // FECHA
              ListTile(
                contentPadding: EdgeInsets.zero,
                leading: const Icon(Icons.calendar_month),
                title: const Text('Fecha de ingreso'),
                subtitle: Text(
                  _fechaIngreso == null
                      ? 'Seleccione una fecha'
                      : '${_fechaIngreso!.day.toString().padLeft(2, '0')}/'
                          '${_fechaIngreso!.month.toString().padLeft(2, '0')}/'
                          '${_fechaIngreso!.year}',
                ),
                trailing: FilledButton.tonal(
                  onPressed: _seleccionarFecha,
                  child: const Text('Seleccionar'),
                ),
              ),

              const SizedBox(height: 8),

              // PERECIBLE
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('¿Producto perecible?'),
                subtitle: Text(
                  _perecible ? 'Sí' : 'No',
                ),
                value: _perecible,
                onChanged: (bool valor) {
                  setState(() {
                    _perecible = valor;
                  });
                },
              ),

              const SizedBox(height: 20),

              // BOTÓN REGISTRAR
              SizedBox(
                width: double.infinity,
                child: FilledButton.icon(
                  onPressed: _registrarProducto,
                  icon: const Icon(Icons.add_circle_outline),
                  label: const Text('Registrar producto'),
                ),
              ),

              const SizedBox(height: 12),

              // BOTÓN VER TABLA
              SizedBox(
                width: double.infinity,
                child: OutlinedButton.icon(
                  onPressed: _mostrarProductos,
                  icon: const Icon(Icons.table_chart_outlined),
                  label: const Text('Ver productos registrados'),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}